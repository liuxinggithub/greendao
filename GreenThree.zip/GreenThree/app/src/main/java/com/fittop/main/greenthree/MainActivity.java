package com.fittop.main.greenthree;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /**
         * 初始化数据库
         * */
        initDatabase();

        /**
         * 添加数据
         * */
        addData();
        /**
         *删除数据
         * */
        deleteData();
        /**
         *修改数据
         * */
        modifyData();
        /**
         *查询数据
         * */
        queryData();

    }

    private void queryData() {
        List<User> list=userDao.queryBuilder()
                .where(UserDao.Properties.Id.between(1,15)).limit(5).build().list();
        for(int i=0;i<list.size();i++){

            Log.d("google_lenve","search: "+list.get(i).toString());
        }

    }

    private void modifyData() {
        User user=userDao.queryBuilder().where(UserDao.Properties.Id.ge(9), UserDao.Properties.Username.like("%haha%")).build().unique();
        if(user == null){

            Toast.makeText(MainActivity.this,"用户不存在！",Toast.LENGTH_SHORT).show();
        }else{
            user.setUsername("李小光");
            userDao.update(user);
        }


    }

    private void deleteData() {
        List<User> userList = userDao.queryBuilder().where(UserDao.Properties.Id.le(9)).build().list();
        for (User user : userList) {
            userDao.delete(user);//删除ID小于9的数据
        }

        User user = userDao.queryBuilder().where(UserDao.Properties.Id.eq(15)).build().unique();
        if (user == null) {
            Toast.makeText(MainActivity.this, "用户不存在", Toast.LENGTH_SHORT).show();
        } else {
            userDao.deleteByKey(user.getId());//根据ID删除
        }

        userDao.deleteAll();//一次性删除


    }

    private void addData() {
        Random random = new Random();
        User user = new User(null, "zhaosi" + random.nextInt(9999), "赵四");
        userDao.insert(user);

    }

    private void initDatabase() {
        DaoMaster.DevOpenHelper devOpenHelper = new DaoMaster.DevOpenHelper(getApplicationContext(), "lenve.db", null);
        DaoMaster daoMaster = new DaoMaster(devOpenHelper.getWritableDb());
        DaoSession daoSession = daoMaster.newSession();
        userDao = daoSession.getUserDao();

    }


}
