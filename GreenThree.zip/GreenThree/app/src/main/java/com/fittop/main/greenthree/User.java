package com.fittop.main.greenthree;

import android.support.annotation.IdRes;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Generated;

/**
 * Created by Administrator on 2017/5/16.
 */
@Entity
public class User {

    @Id
         Long id;
    @Property(nameInDb="USERNAME")
         String username;
    @Property(nameInDb = "NICKNAME")
         String nickname;
public String getNickname() {
     return this.nickname;
}
public void setNickname(String nickname) {
     this.nickname = nickname;
}
public String getUsername() {
     return this.username;
}
public void setUsername(String username) {
     this.username = username;
}
public Long getId() {
     return this.id;
}
public void setId(Long id) {
     this.id = id;
}
@Generated(hash = 523935516)
public User(Long id, String username, String nickname) {
     this.id = id;
     this.username = username;
     this.nickname = nickname;
}
@Generated(hash = 586692638)
public User() {
}



}
